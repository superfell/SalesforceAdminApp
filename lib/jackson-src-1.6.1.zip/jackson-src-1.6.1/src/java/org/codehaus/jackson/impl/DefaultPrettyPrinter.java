package org.codehaus.jackson.impl;

/**
 * Deprecated version of the default pretty printer.
 * 
 * @deprecated Moved to {@link org.codehaus.jackson.util.DefaultPrettyPrinter}
 */
@Deprecated
public class DefaultPrettyPrinter
    extends org.codehaus.jackson.util.DefaultPrettyPrinter
{

}
